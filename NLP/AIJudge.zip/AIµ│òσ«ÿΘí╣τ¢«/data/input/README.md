# 输入数据

由于文件太大，因此无法上传到 Github 上，若需要相关数据，可以发 issue 联系我。该目录结构如下：

```
input
    dir.md
    law.txt
    stop.txt
    test.txt
    train.txt
    README.md
```