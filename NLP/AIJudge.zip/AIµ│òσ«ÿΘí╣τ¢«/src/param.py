# coding=utf-8

data_path = '../data'

cv_train_num = 100000  # 用于交叉验证

train_num = 120000
test_num = 90000

w2v_dim = 300

seed = 2017
